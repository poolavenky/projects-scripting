# ansible-aws-vpc
Create an AWS VPC from scratch with Ansible. 3 different topologies.

Documentation : [here](http://jeremievallee.com/2016/07/27/aws-vpc-ansible/)
